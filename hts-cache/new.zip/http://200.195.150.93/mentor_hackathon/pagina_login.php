<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="content-language" content="pt_BR" />


        <meta name="keywords" content="Hackathon, Paraná, 2017,  Obras, Públicas, Transporte, Público, Secretaria, Estado, Paraná, Desenvolvimento, Urbano,SEDU,  incentivar, desenvolvimento, aplicações, gestão, pública" />
        <meta name="description" content="O Hackathon Paraná 2017 tem como objetivo incentivar o desenvolvimento de aplicações voltadas às áreas de Obras Públicas e Transporte Público. Sendo uma iniciativa da Secretaria de Estado do Desenvolvimento Urbano." />
        <title>Hackathon Paraná 2017</title>
        <meta name="copyright" content="Copyright © 2017" />
        <meta name="author" content="ParanaCidade" />
        <!-- Bootstrap Core CSS -->
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
        <link href="https://fonts.googleapis.com/css?family=Roboto|Share+Tech" rel="stylesheet">

        <!-- Plugin CSS -->
        <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

        <!-- Theme CSS -->
        <link href="css/creative.min.css" rel="stylesheet">
        <link href="css/creative.min.css" rel="stylesheet">
        <link href="css/slick.css" rel="stylesheet">
        <link href="css/slick-theme.css" rel="stylesheet">


    </head>

    <body>


        <section class="bg-primary" id="login" style="height: 100%">
            <div class="particle_about"></div>
            <div class="container bloco_content">
                <div class="">
                    <div class="col-lg-10 col-lg-offset-1 text-center">




                        <img src="img/paranacidade_demoday.png" class="logo" alt="Hackathon Paraná 2017" style="max-height: 200px; max-width: 400px; width: auto;height: auto;"/>
                        <br><br>
                        <div class="container">
                            <div class="">
                                <div class="col-lg-8 col-lg-offset-2 text-center">
                                    <form action="login.php" method="post" class="form-horizontal">



                                        <div class="form-group">

                                            <label class="col-sm-2 control-label">Usuário</label>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control" name="login">
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Senha</label>
                                            <div class="col-sm-4">
                                                <input type="password" class="form-control" name="senha">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <br>
                                            <div class="col-sm-6">
                                                <button type="submit" class="btn btn-primary">
                                                    <span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span> Login
                                                </button>
                                            </div>
                                        </div>




                                    </form>
                                </div>
                            </div>
                            </section>

                            <!-- jQuery -->
                            <script src="vendor/jquery/jquery.min.js"></script>

                            <!-- Bootstrap Core JavaScript -->
                            <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

                            <!-- Plugin JavaScript -->
                            <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
                            <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
                            <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

                            <!-- Theme JavaScript -->
                            <script src="js/validator.js"></script>
                            <script src="js/jparticle.jquery.min.js"></script>
                            <script src="js/jquery.maskedinput.min.js"></script>
                            <script src="js/slick.min.js"></script>
                            <script src="js/creative.min.js"></script>

                            </body>

                            </html>
